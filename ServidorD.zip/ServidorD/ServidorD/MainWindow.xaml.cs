﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using LiveCharts;
using LiveCharts.Wpf;
using lvc = LiveCharts.Wpf;
using System.Windows.Threading;

namespace ServidorD
{
    public partial class MainWindow : Window
    {
        private TcpListener _listener;
        private List<ClientInfo> _clients = new List<ClientInfo>();
        private Dictionary<string, DateTime> _clientLastReport = new Dictionary<string, DateTime>();
        private DispatcherTimer _updateTimer;
        public SeriesCollection PieSeries { get; set; }
        
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            PieSeries = new SeriesCollection();
            StartServer();
            UpdateClientsDataGrid();

            // Configurar el temporizador para actualizar cada 1 minuto (60000 ms)
            _updateTimer = new DispatcherTimer();
            _updateTimer.Interval = TimeSpan.FromMinutes(1); // Actualiza cada minuto
            _updateTimer.Tick += UpdateTimer_Tick; // Asocia el evento Tick
            _updateTimer.Start(); // Inicia el temporizador


        }
        private void UpdateTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                UpdateClientsDataGrid(); // Actualiza la interfaz
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error durante la actualización periódica: {ex.Message}");
            }
        }
        protected override void OnClosed(EventArgs e)
        {
            _updateTimer.Stop(); // Detiene el temporizador
            base.OnClosed(e);
        }

        private async void StartServer()
        {
            try
            {
                _listener = new TcpListener(IPAddress.Any, 15100);
                _listener.Start();
                await Task.Run(() => ListenForClients());
            }
            catch (SocketException ex)
            {
                MessageBox.Show($"Error al iniciar el servidor: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error desconocido al iniciar el servidor: {ex.Message}");
            }
        }

        private void ListenForClients()
        {
            try
            {
                while (true)
                {
                    try
                    {
                        TcpClient client = _listener.AcceptTcpClient();
                        Task.Run(() => HandleClient(client));
                    }
                    catch (SocketException ex)
                    {
                        MessageBox.Show($"Error de socket al aceptar cliente: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error inesperado al aceptar cliente: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error crítico en ListenForClients: {ex.Message}");
            }
        }

        private void HandleClient(TcpClient client)
        {
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    // Formato esperado: clientName|ipAddress|diskName1,totalSpace1,usedSpace1;diskName2,totalSpace2,usedSpace2;...
                    string[] clientData = data.Split('|');
                    if (clientData.Length != 3)
                    {
                        MessageBox.Show("Formato de datos incorrecto.");
                        return;
                    }

                    string clientName = clientData[0];
                    string ipAddress = clientData[1];
                    string[] disksData = clientData[2].Split(';');

                    // Guardar la información del cliente y los discos
                    SaveClientInfo(clientName, ipAddress, disksData);

                    // Actualizar el último reporte del cliente
                    _clientLastReport[ipAddress] = DateTime.Now;

                    // Actualizar la interfaz de usuario en el hilo de la UI
                    Dispatcher.Invoke(() => UpdateClientsDataGrid());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al manejar cliente: {ex.Message}");
            }
            finally
            {
                client.Close();
            }
        }

        private void SaveClientInfo(string clientName, string ipAddress, string[] disksData)
        {
            try
            {
                string connectionString = "Server=MALONDY\\SQLEXPRESS;Database=dbServidor;Integrated Security=True;";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Verificar si el cliente ya existe en la base de datos
                    string query = "SELECT idClient FROM Clients WHERE ipAddress = @ipAddress";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ipAddress", ipAddress);
                    object result = command.ExecuteScalar();

                    int clientId;

                    if (result != null) // Si el cliente ya existe
                    {
                        clientId = Convert.ToInt32(result);
                    }
                    else // Si el cliente no existe
                    {
                        // Insertar en Clients
                        query = @"
                    INSERT INTO Clients (clientName, ipAddress)
                    VALUES (@clientName, @ipAddress);
                    SELECT SCOPE_IDENTITY();
                ";
                        command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@clientName", clientName);
                        command.Parameters.AddWithValue("@ipAddress", ipAddress);
                        clientId = Convert.ToInt32(command.ExecuteScalar());
                    }

                    // Guardar la información de cada disco
                    foreach (string diskData in disksData)
                    {
                        string[] diskInfo = diskData.Split(',');
                        if (diskInfo.Length != 3)
                        {
                            MessageBox.Show("Formato de disco incorrecto.");
                            continue;
                        }

                        string diskName = diskInfo[0];
                        long totalSpace = long.Parse(diskInfo[1]);
                        long usedSpace = long.Parse(diskInfo[2]);

                        // Verificar si el disco ya existe para este cliente
                        query = @"
                    SELECT idDisk FROM DiskInfo WHERE idClient = @idClient AND diskName = @diskName;
                ";
                        command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@idClient", clientId);
                        command.Parameters.AddWithValue("@diskName", diskName);
                        object diskResult = command.ExecuteScalar();

                        if (diskResult != null) // Si el disco ya existe, actualizar
                        {
                            query = @"
                        UPDATE DiskInfo
                        SET totalSpace = @totalSpace, usedSpace = @usedSpace, lastUpdate = GETDATE()
                        WHERE idDisk = @idDisk;
                    ";
                            command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@idDisk", diskResult);
                        }
                        else // Si el disco no existe, insertar
                        {
                            query = @"
                        INSERT INTO DiskInfo (idClient, diskName, totalSpace, usedSpace)
                        VALUES (@idClient, @diskName, @totalSpace, @usedSpace);
                    ";
                            command = new SqlCommand(query, connection);
                        }

                        command.Parameters.AddWithValue("@idClient", clientId);
                        command.Parameters.AddWithValue("@diskName", diskName);
                        command.Parameters.AddWithValue("@totalSpace", totalSpace);
                        command.Parameters.AddWithValue("@usedSpace", usedSpace);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar en la base de datos: {ex.Message}");
            }
        }
        private void UpdateClientsDataGrid()
        {
            try
            {
                _clients.Clear();
                long totalSpaceAllClients = 0;
                long usedSpaceAllClients = 0;

                string connectionString = "Server=MALONDY\\SQLEXPRESS;Database=dbServidor;Integrated Security=True;";
                Dictionary<string, List<ClientInfo>> clientsById = new Dictionary<string, List<ClientInfo>>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT c.clientName, c.ipAddress, d.diskName, d.totalSpace, d.usedSpace, d.idClient " +
                                   "FROM Clients c JOIN DiskInfo d ON c.idClient = d.idClient";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string clientIp = reader["ipAddress"].ToString();
                        string idClient = reader["idClient"].ToString();
                        long totalSpace = (long)reader["totalSpace"];
                        long usedSpace = (long)reader["usedSpace"];

                        bool state = _clientLastReport.ContainsKey(clientIp) && (DateTime.Now - _clientLastReport[clientIp]).TotalMinutes <= 5;
                        var clientInfo = new ClientInfo
                        {
                            ClientName = reader["clientName"].ToString(),
                            IPAddress = clientIp,
                            DiskName = reader["diskName"].ToString(),
                            TotalSpace = totalSpace / 1_073_741_824, // Convertir a GB
                            UsedSpace = usedSpace / 1_073_741_824, // Convertir a GB
                            FreeSpace = (totalSpace - usedSpace) / 1_073_741_824, // Convertir a GB
                            State = state
                        };

                        if (!clientsById.ContainsKey(idClient))
                        {
                            clientsById[idClient] = new List<ClientInfo>();
                        }
                        clientsById[idClient].Add(clientInfo);

                        totalSpaceAllClients += totalSpace;
                        usedSpaceAllClients += usedSpace;
                    }
                }

                Dispatcher.Invoke(() =>
                {
                    double totalSpaceInTB = totalSpaceAllClients / 1_048_576_000_000.0;
                    double usedSpaceInTB = usedSpaceAllClients / 1_048_576_000_000.0;

                    EspacioTotalTextBlock.Text = $"Espacio Total: {totalSpaceInTB:F2} TB";
                    EspacioUtilizadoTextBlock.Text = $"Espacio Utilizado: {usedSpaceInTB:F2} TB";

                    ClientsGrid.Children.Clear();
                    int columnas = 4;
                    int filas = (clientsById.Count + columnas - 1) / columnas;
                    ClientsGrid.Rows = filas;
                    ClientsGrid.Columns = columnas;

                    foreach (var clientEntry in clientsById)
                    {
                        var clientInfoList = clientEntry.Value;
                        var firstClient = clientInfoList[0];

                        var clientPanel = new Border
                        {
                            Background = firstClient.State ?
                                new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#fffffe")) :
                                new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#358B51")),
                            Margin = new Thickness(5),
                            BorderBrush = System.Windows.Media.Brushes.Black,
                            BorderThickness = new Thickness(1),
                            VerticalAlignment = VerticalAlignment.Center,
                            Width = 250,
                            Height = 300,
                            HorizontalAlignment = HorizontalAlignment.Center
                        };

                        var stackPanel = new StackPanel
                        {
                            VerticalAlignment = VerticalAlignment.Center,
                            HorizontalAlignment = HorizontalAlignment.Center
                        };

                        stackPanel.Children.Add(new TextBlock
                        {
                            Text = firstClient.ClientName,
                            Foreground = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#1b2d45")),
                            VerticalAlignment = VerticalAlignment.Center,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            FontWeight = FontWeights.Bold,
                            FontSize = 16
                        });

                        stackPanel.Children.Add(new TextBlock
                        {
                            Text = $"IP: {firstClient.IPAddress}",
                            Foreground = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#1b2d45")),
                            VerticalAlignment = VerticalAlignment.Center,
                            HorizontalAlignment = HorizontalAlignment.Center
                        });

                        foreach (var client in clientInfoList)
                        {
                            var pieChart = new lvc.PieChart
                            {
                                Width = 30,
                                Height = 30,
                                Series = new SeriesCollection
                {
                    new PieSeries
                    {
                        Title = "Usado",
                        Values = new ChartValues<double> { client.UsedSpace },
                        DataLabels = true,
                        Fill = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#00214d"))
                    },
                    new PieSeries
                    {
                        Title = "Libre",
                        Values = new ChartValues<double> { client.FreeSpace },
                        DataLabels = true,
                        Fill = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FF194B42"))
                    }
                }
                            };

                            stackPanel.Children.Add(new TextBlock
                            {
                                Text = $"Disco: {client.DiskName}",
                                Foreground = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#1b2d45")),
                                VerticalAlignment = VerticalAlignment.Center,
                                HorizontalAlignment = HorizontalAlignment.Center
                            });

                            stackPanel.Children.Add(new TextBlock
                            {
                                Text = $"Total: {client.TotalSpace} GB",
                                Foreground = new System.Windows.Media.SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#1b2d45")),
                                VerticalAlignment = VerticalAlignment.Center,
                                HorizontalAlignment = HorizontalAlignment.Center
                            });

                            stackPanel.Children.Add(pieChart);
                        }

                        clientPanel.Child = stackPanel;
                        ClientsGrid.Children.Add(clientPanel);
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en UpdateClientsDataGrid: {ex.Message}");
            }
        }


        private void SaveClientInfo(string clientName, string ipAddress, string diskName, long totalSpace, long usedSpace)
        {
            try
            {
                string connectionString = "Server=MALONDY\\SQLEXPRESS;Database=dbServidor;Integrated Security=True;";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Verificar si el cliente ya existe en la base de datos
                    string query = "SELECT idClient FROM Clients WHERE ipAddress = @ipAddress";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ipAddress", ipAddress);
                    object result = command.ExecuteScalar();

                    int clientId;

                    if (result != null) // Si el cliente ya existe
                    {
                        clientId = Convert.ToInt32(result);

                        // Actualizar la información del disco en DiskInfo si ya existe
                        query = @"
                    UPDATE DiskInfo
                    SET totalSpace = @totalSpace, usedSpace = @usedSpace, lastUpdate = GETDATE()
                    WHERE idClient = @idClient AND diskName = @diskName;
                ";
                        command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@idClient", clientId);
                        command.Parameters.AddWithValue("@diskName", diskName);
                        command.Parameters.AddWithValue("@totalSpace", totalSpace);
                        command.Parameters.AddWithValue("@usedSpace", usedSpace);
                        int rowsAffected = command.ExecuteNonQuery();

                        // Si no se actualizó ninguna fila, insertar un nuevo registro en DiskInfo
                        if (rowsAffected == 0)
                        {
                            query = @"
                        INSERT INTO DiskInfo (idClient, diskName, totalSpace, usedSpace)
                        VALUES (@idClient, @diskName, @totalSpace, @usedSpace);
                    ";
                            command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@idClient", clientId);
                            command.Parameters.AddWithValue("@diskName", diskName);
                            command.Parameters.AddWithValue("@totalSpace", totalSpace);
                            command.Parameters.AddWithValue("@usedSpace", usedSpace);
                            command.ExecuteNonQuery();
                        }
                    }
                    else // Si el cliente no existe
                    {
                        // Insertar en Clients
                        query = @"
                    INSERT INTO Clients (clientName, ipAddress)
                    VALUES (@clientName, @ipAddress);
                    SELECT SCOPE_IDENTITY();
                ";
                        command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@clientName", clientName);
                        command.Parameters.AddWithValue("@ipAddress", ipAddress);
                        clientId = Convert.ToInt32(command.ExecuteScalar());

                        // Insertar en DiskInfo
                        query = @"
                    INSERT INTO DiskInfo (idClient, diskName, totalSpace, usedSpace)
                    VALUES (@idClient, @diskName, @totalSpace, @usedSpace);
                ";
                        command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@idClient", clientId);
                        command.Parameters.AddWithValue("@diskName", diskName);
                        command.Parameters.AddWithValue("@totalSpace", totalSpace);
                        command.Parameters.AddWithValue("@usedSpace", usedSpace);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar en la base de datos: {ex.Message}");
            }
        }
    }
    public class ClientInfo
    {
        public string ClientName { get; set; }
        public string IPAddress { get; set; }
        public string DiskName { get; set; }
        public long TotalSpace { get; set; }
        public long UsedSpace { get; set; }
        public long FreeSpace { get; set; }
        public bool State { get; set; }
    }
}