﻿using System;
using System.IO;
using System.Text.Json;
namespace ClienteD
{
    public class ClientConfig
    {
        public string ClientName { get; set; }

        // Guardar la configuración en un archivo JSON
        public void Save(string filePath)
        {
            string json = JsonSerializer.Serialize(this);
            File.WriteAllText(filePath, json);
        }

        // Cargar la configuración desde un archivo JSON
        public static ClientConfig Load(string filePath)
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<ClientConfig>(json);
            }
            return new ClientConfig();
        }
    }
}
