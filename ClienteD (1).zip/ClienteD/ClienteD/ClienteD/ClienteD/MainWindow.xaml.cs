﻿using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Linq;

namespace ClienteD
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string configFilePath = "client_config.json";
            ClientConfig config = ClientConfig.Load(configFilePath);

            if (!string.IsNullOrEmpty(config.ClientName))
            {
                // Si el nombre ya está guardado, ocultar el TextBox y el Button
                NameTextBox.Visibility = Visibility.Collapsed;
                SendButton.Visibility = Visibility.Collapsed;

                // Mostrar el nombre en grande
                NameDisplayTextBlock.Text = config.ClientName;
                NameDisplayTextBlock.Visibility = Visibility.Visible;
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string configFilePath = "client_config.json";
            ClientConfig config = ClientConfig.Load(configFilePath);

            // Si el nombre no está guardado, pedirlo
            if (string.IsNullOrEmpty(config.ClientName))
            {
                config.ClientName = NameTextBox.Text;
                config.Save(configFilePath); // Guardar el nombre para futuras ejecuciones
            }

            string clientName = config.ClientName;

            // Obtener la dirección IP del cliente
            string ipAddress = Dns.GetHostEntry(Dns.GetHostName()).AddressList
                .FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork)?.ToString();

            // Obtener la lista de discos disponibles
            DriveInfo[] drives = DriveInfo.GetDrives();

            StringBuilder dataBuilder = new StringBuilder();
            dataBuilder.Append(clientName + "|");
            dataBuilder.Append(ipAddress + "|"); // Incluir la dirección IP

            foreach (DriveInfo drive in drives)
            {
                if (drive.IsReady)
                {
                    string diskName = drive.Name; // Nombre del disco (por ejemplo, "C:\")
                    long totalSpace = drive.TotalSize;
                    long freeSpace = drive.AvailableFreeSpace;
                    long usedSpace = totalSpace - freeSpace;

                    dataBuilder.Append($"{diskName},{totalSpace},{usedSpace};");
                }
            }

            string data = dataBuilder.ToString().TrimEnd(';');

            try
            {
                TcpClient client = new TcpClient("192.168.86.250", 15100);
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] buffer = Encoding.UTF8.GetBytes(data);
                    stream.Write(buffer, 0, buffer.Length);
                }
                client.Close();

                // Mostrar información en la interfaz
                InfoTextBlock.Text = $"Nombre: {clientName}\n";
                foreach (DriveInfo drive in drives)
                {
                    if (drive.IsReady)
                    {
                        InfoTextBlock.Text += $"Disco: {drive.Name}\n" +
                                             $"Total: {((double)drive.TotalSize / (1024 * 1024 * 1024)):F2} GB\n" +
                                             $"Ocupado: {((double)(drive.TotalSize - drive.AvailableFreeSpace) / (1024 * 1024 * 1024)):F2} GB\n" +
                                             $"Libre: {((double)drive.AvailableFreeSpace / (1024 * 1024 * 1024)):F2} GB\n\n";
                    }
                }

                // Ocultar el TextBox y el Button
                NameTextBox.Visibility = Visibility.Collapsed;
                SendButton.Visibility = Visibility.Collapsed;

                // Mostrar el nombre en grande
                NameDisplayTextBlock.Text = clientName;
                NameDisplayTextBlock.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con el servidor: " + ex.Message);
            }
        }
    }
}